/*
Functions - everything our virtual world is doing right now - is this a good design?
 */

final class Functions
{
}
